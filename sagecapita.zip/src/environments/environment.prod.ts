export const environment = {
  production: true,
  apiUrl: 'https://api.sagecapita.com/api',
  cloudinary_cloudname: 'dzx23evie'
};
