// import { NumberMillionsPipe } from './number-millions.pipe';
// import { DecimalPipe } from '@angular/common';

// describe('NumberMillionsPipe', () => {
//   it('create an instance', (decimalPipe: DecimalPipe) => {
//     const pipe = new NumberMillionsPipe(decimalPipe);
//     expect(pipe).toBeTruthy();
//   });
// });
