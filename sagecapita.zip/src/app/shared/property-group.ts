export interface PropertyGroup {
    name: string;
    photo: string;
    count: number;
}
