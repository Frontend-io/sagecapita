export enum Languages {
    EN = 'EN',
    FR = 'FR',
}
