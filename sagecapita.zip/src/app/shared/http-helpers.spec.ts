import { HttpHelpers } from './http-helpers';

describe('HttpHelpers', () => {
  it('should create an instance', () => {
    expect(new HttpHelpers()).toBeTruthy();
  });
});
