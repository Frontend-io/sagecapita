export enum Currencies {
    USD = 'USD',
    GBP = 'GBP',
    NGN = 'NGN'
}
