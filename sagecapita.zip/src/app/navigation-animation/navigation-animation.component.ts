import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigation-animation',
  templateUrl: './navigation-animation.component.html',
  styleUrls: ['./navigation-animation.component.css']
})
export class NavigationAnimationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
