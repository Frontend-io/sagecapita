import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-button-aside',
  templateUrl: './info-button-aside.component.html',
  styleUrls: ['./info-button-aside.component.css']
})
export class InfoButtonAsideComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
