import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-aside',
  templateUrl: './info-aside.component.html',
  styleUrls: ['./info-aside.component.css']
})
export class InfoAsideComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
